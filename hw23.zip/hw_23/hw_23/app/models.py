from django.db import models
from django.contrib.postgres import fields


class Person(models.Model):
    nickname = models.CharField(max_length=30)
    age = models.IntegerField()

    def __str__(self):
        return self.nickname

class Room(models.Model):
    name = models.CharField(max_length=100)
    reservedPerson = models.ForeignKey(Person, on_delete=models.CASCADE)
    participants = fields.ArrayField(base_field=models.CharField(max_length=100), max_length=5)
    reserving = fields.DateRangeField()
    max_time = fields.IntegerRangeField()